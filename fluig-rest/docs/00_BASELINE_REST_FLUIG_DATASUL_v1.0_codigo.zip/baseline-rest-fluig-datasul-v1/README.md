# Baseline REST Fluig-Datasul v1.0

Marco técnico definido em 03/09/2026 após a validação da primeira integração
REST completa entre Widget Fluig, Dataset, serviço autorizado, API Datasul e
procedure ABL.

O Controle de Embalagens da Branco Peres será o primeiro projeto da Data IT
implementado integralmente neste padrão REST.

## Arquivos

- `listarCentroDistribuicaoBO.js`: chamada assíncrona do Widget.
- `dsControleEmbalagensAPI.js`: proxy seguro no Fluig.
- `pi-listar-cds.p`: leitura dos query parameters e regra de consulta ABL.

## Contrato validado

Entrada da API:

```text
GET .../cd-ressuprimento/?filtro=11205&limit=20
```

No `ut-api`, os parâmetros chegam como arrays dentro de `queryParams`:

```json
{
  "queryParams": {
    "filtro": ["11205"],
    "limit": ["20"]
  }
}
```

Saída:

```json
{
  "sucesso": true,
  "total": 1,
  "dados": [
    {
      "codEstabel": "11205",
      "nomeEstabel": "RODRIGO BRANCO PERES E OUTRO"
    }
  ],
  "filtroRecebido": "11205",
  "limitRecebido": 20
}
```

## Publicação

Após compilar uma API, o `.r` deve estar no PROPATH utilizado pela aplicação
PASOE correspondente. Quando existirem agentes com versões carregadas em
memória, executar refresh somente na aplicação do ambiente correto. Nunca
expor cookies, access tokens, refresh tokens ou o `oInput` completo em retorno
ou log.
